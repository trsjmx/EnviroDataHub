import requests
import time
import random

API_URL = "http://localhost:5000/devices/telemetry"
DEVICE_ID = 1 

def generate_data():
    return {
        "device_id": DEVICE_ID,
        "temperature": round(random.uniform(20.0, 25.0), 2),
        "humidity": round(random.uniform(30.0, 50.0), 2)
    }

while True:
    data = generate_data()
    response = requests.post(API_URL, json=data)
    print(f"Sent data: {data}, Response: {response.status_code}")
    time.sleep(60)
 
