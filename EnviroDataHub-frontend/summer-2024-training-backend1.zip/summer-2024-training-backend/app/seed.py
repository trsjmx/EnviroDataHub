from app import app, db, User, Device
import datetime


def seed_data():
    with app.app_context():
        # Create sample users
       user1 = User(username='Arwa_Gh', password='password123', email='Arwa_Gh@example.com', role='admin', created_at=datetime.datetime.utcnow(), updated_at=datetime.datetime.utcnow())
       user2 = User(username='Ahmed_Gh', password='password456', email='Ahmed_Gh@example.com', role='user', created_at=datetime.datetime.utcnow(), updated_at=datetime.datetime.utcnow())

        # Create sample devices associated with users
       device1 = Device(device_name='Sensor1', device_type='Temperature',created_at=datetime.datetime.utcnow(), updated_at=datetime.datetime.utcnow(),user=user1)
       device2 = Device(device_name='Sensor2', device_type='Humidity',created_at=datetime.datetime.utcnow(), updated_at=datetime.datetime.utcnow(), user=user2)

        # Add users and devices to session
       db.session.add_all([user1, user2, device1, device2])
       db.session.commit()

if __name__ == '__main__':
    seed_data()


