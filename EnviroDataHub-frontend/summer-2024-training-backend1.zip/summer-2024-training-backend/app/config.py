import os

class Config:
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'postgresql://postgres:Pp8517&8517@localhost:5432/EnviroData Hub DB'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or '54333'

class DevelopmentConfig(Config):
    DEBUG = True

config_by_name = dict(
    dev=DevelopmentConfig,
)


