from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import logging
from datetime import datetime
from config import config_by_name

app = Flask(__name__)
app.config.from_object(config_by_name['dev'])  # Use the development configuration
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Database models
class User(db.Model):
    __tablename__ = 'Users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(10), nullable=False)
    created_at = db.Column(db.TIMESTAMP, nullable=True, server_default=db.func.now())
    updated_at = db.Column(db.TIMESTAMP, nullable=True, server_default=db.func.now(), onupdate=db.func.now())

class Device(db.Model):
    __tablename__ = 'Devices'
    id = db.Column(db.Integer, primary_key=True)
    device_name = db.Column(db.String(100), unique=True, nullable=False)
    device_type = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.TIMESTAMP, nullable=True, server_default=db.func.now())
    updated_at = db.Column(db.TIMESTAMP, nullable=True, server_default=db.func.now(), onupdate=db.func.now())

    user_id = db.Column(db.Integer, db.ForeignKey('Users.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('Devices', lazy=True))

class EnvironmentalData(db.Model):
    __tablename__ = 'EnvironmentalData'
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.Integer, db.ForeignKey('Devices.id'), nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    humidity = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.TIMESTAMP, nullable=False, server_default=db.func.now())

class HistoricalData(db.Model):
    __tablename__ = 'HistoricalData'
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.Integer, db.ForeignKey('Devices.id'), nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    humidity = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.TIMESTAMP, nullable=False, server_default=db.func.now())

class Session(db.Model):
    __tablename__ = 'Sessions'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('Users.id'), nullable=False)
    session_token = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.TIMESTAMP, nullable=False, server_default=db.func.now())
    expires_at = db.Column(db.TIMESTAMP, nullable=False)

# API Endpoints
@app.route('/login', methods=['POST'])
def login():
    return jsonify({"message": "Login successful"}), 200

@app.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    user_list = []
    for user in users:
        user_list.append({
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "created_at": user.created_at,
            "updated_at": user.updated_at
        })
    return jsonify({"users": user_list}), 200

@app.route('/users', methods=['POST'])
def create_user():
    data = request.get_json()
    new_user = User(
        username=data['username'],
        password=data['password'],  
        email=data['email'],
        role=data['role'],
        created_at=data.get('created_at', datetime.utcnow()),
        updated_at=data.get('updated_at', datetime.utcnow())
    )
    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "User created", "user_id": new_user.id}), 201

@app.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify({
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "role": user.role,
        "created_at": user.created_at,
        "updated_at": user.updated_at
    }), 200

@app.route('/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    user.username = data.get('username', user.username)
    user.password = data.get('password', user.password)  
    user.email = data.get('email', user.email)
    user.role = data.get('role', user.role)
    db.session.commit()
    return jsonify({"message": "User updated", "user_id": user.id}), 200

@app.route('/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return jsonify({"message": "User deleted"}), 204

@app.route('/devices', methods=['GET'])
def get_devices():
    devices = Device.query.all()
    device_list = []
    for device in devices:
        device_list.append({
            "id": device.id,
            "device_name": device.device_name,
            "device_type": device.device_type,
            "created_at": device.created_at,
            "updated_at": device.updated_at
        })
    return jsonify({"devices": device_list}), 200

@app.route('/devices', methods=['POST'])
def create_device():
    data = request.get_json()
    new_device = Device(
        device_name=data['device_name'],
        device_type=data['device_type'],
        created_at=data.get('created_at', datetime.utcnow()),
        updated_at=data.get('updated_at', datetime.utcnow()),
        user_id=data['user_id']
    )
    db.session.add(new_device)
    db.session.commit()
    return jsonify({"message": "Device created", "device_id": new_device.id}), 201

@app.route('/devices/<int:device_id>', methods=['GET'])
def get_device(device_id):
    device = Device.query.get_or_404(device_id)
    return jsonify({
        "id": device.id,
        "device_name": device.device_name,
        "device_type": device.device_type,
        "created_at": device.created_at,
        "updated_at": device.updated_at
    }), 200

@app.route('/devices/<int:device_id>', methods=['PUT'])
def update_device(device_id):
    device = Device.query.get_or_404(device_id)
    data = request.get_json()
    device.device_name = data.get('device_name', device.device_name)
    device.device_type = data.get('device_type', device.device_type)
    db.session.commit()
    return jsonify({"message": "Device updated", "device_id": device.id}), 200

@app.route('/devices/<int:device_id>', methods=['DELETE'])
def delete_device(device_id):
    device = Device.query.get_or_404(device_id)
    db.session.delete(device)
    db.session.commit()
    return jsonify({"message": "Device deleted"}), 204

@app.route('/devices/<string:device_name>/data', methods=['GET'])
def get_time_series_data(device_name):
    search_start_date = request.args.get('search_start_date')
    search_end_date = request.args.get('search_end_date')
    data = EnvironmentalData.query.join(Device).filter(
        Device.device_name == device_name,
        EnvironmentalData.timestamp >= search_start_date,
        EnvironmentalData.timestamp <= search_end_date
    ).all()
    data_list = [{
        "temperature": d.temperature,
        "humidity": d.humidity,
        "timestamp": d.timestamp
    } for d in data]
    return jsonify({"device_name": device_name, "data": data_list}), 200

@app.route('/devices/<string:device_name>/latest', methods=['GET'])
def get_latest_data(device_name):
    data = EnvironmentalData.query.join(Device).filter(
        Device.device_name == device_name
    ).order_by(EnvironmentalData.timestamp.desc()).first()
    if data:
        data_response = {
            "temperature": data.temperature,
            "humidity": data.humidity,
            "timestamp": data.timestamp
        }
        return jsonify({"device_name": device_name, "latest_data": data_response}), 200
    else:
        return jsonify({"message": "No data found for the specified device"}), 404

@app.route('/devices/telemetry', methods=['POST'])
def post_device_telemetry():
    data = request.get_json()
    new_data = EnvironmentalData(
        device_id=data['device_id'],
        temperature=data['temperature'],
        humidity=data['humidity'],
        timestamp=datetime.utcnow()
    )
    db.session.add(new_data)
    db.session.commit()
    return jsonify({"message": "Telemetry data received"}), 201


@app.route('/get-api-test/<path_param>', methods=['GET'])
def get_api_test(path_param: str):
    try:
        if len(path_param) >= 10:
            return jsonify({"success": True, "data": path_param}), 200
        else:
            return jsonify({"success": False, "errors": ["path_param must be greater than 9 characters"]}), 422
    except Exception as e:
        logging.error(f"get_api_test: {e}")
        return jsonify({"success": False, "errors": ["Internal server error"]}), 500

@app.route('/post-api-test', methods=['POST'])
def post_api_test():
    try:
        data = request.get_json()
        return jsonify({"success": True, "data": data}), 200
    except Exception as e:
        logging.error(f"post_api_test: {e}")
        return jsonify({"success": False, "errors": ["Internal server error"]}), 500


if __name__ == "__main__":
    with app.app_context():
        app.run(debug=True)
